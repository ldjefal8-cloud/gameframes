package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Records the screen with a single MediaProjection + VirtualDisplay feeding a MediaCodec
 * surface. Android 14 allows only one VirtualDisplay per projection, so FPS is measured
 * from the frames the encoder actually produces (frames delivered by the screen capture).
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "gf.start"
        const val ACTION_STOP = "gf.stop"
        private const val CHANNEL = "rec"

        @Volatile var running = false
        @Volatile var lastUri: Uri? = null
        @Volatile var startMs = 0L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val stopping = AtomicBoolean(false)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var outUri: Uri? = null
    @Volatile private var muxerStarted = false
    @Volatile private var frames = 0
    private var lastFrames = 0

    private var overlay: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private val ticker = object : Runnable {
        override fun run() {
            val f = frames
            val fps = f - lastFrames
            lastFrames = f
            val s = (SystemClock.elapsedRealtime() - startMs) / 1000
            overlay?.apply {
                text = "FPS %d\n● %02d:%02d".format(fps, s / 60, s % 60)
                setTextColor(
                    when {
                        fps >= 50 -> Color.parseColor("#4ade80")
                        fps >= 25 -> Color.parseColor("#fbbf24")
                        else -> Color.parseColor("#f87171")
                    }
                )
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                startForegroundNow()
                try {
                    startRecording(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذّر بدء التسجيل: ${e.message}", Toast.LENGTH_LONG).show()
                    abort()
                }
            }
            ACTION_STOP -> {
                if (running) requestStop() else stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Game Frames")
            .setContentText("جارٍ تسجيل الشاشة")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun startRecording(intent: Intent) {
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data") ?: throw IllegalStateException("no permission data")
        val heightOpt = intent.getIntExtra("height", 1080)
        val fps = intent.getIntExtra("fps", 60)
        val bitrate = intent.getIntExtra("bitrate", 8_000_000)
        val landscape = intent.getBooleanExtra("landscape", true)
        val showOverlay = intent.getBooleanExtra("overlay", true)

        val dm = resources.displayMetrics
        val nativeShort = min(dm.widthPixels, dm.heightPixels)
        val nativeLong = max(dm.widthPixels, dm.heightPixels)
        val short = if (heightOpt == 0) nativeShort else min(heightOpt, nativeShort)
        val long = (short.toFloat() * nativeLong / nativeShort).roundToInt()
        // Encoders are happiest with sizes that are multiples of 16.
        val sShort = max(16, short / 16 * 16)
        val sLong = max(16, long / 16 * 16)
        val w = if (landscape) sLong else sShort
        val h = if (landscape) sShort else sLong

        // --- output file in MediaStore (Movies/GameFrames) ---
        val name = "game-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GameFrames")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("cannot create file")
        outUri = uri
        pfd = contentResolver.openFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("cannot open file")

        // --- encoder ---
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = enc.createInputSurface()
        enc.start()
        encoder = enc
        muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // --- projection + single virtual display ---
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { requestStop() }
            }
        }, handler)
        display = proj.createVirtualDisplay(
            "GameFrames", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null
        )

        frames = 0
        lastFrames = 0
        stopping.set(false)
        startMs = SystemClock.elapsedRealtime()
        running = true

        Thread({ drainLoop(enc) }, "gf-drain").start()

        if (showOverlay && android.provider.Settings.canDrawOverlays(this)) addOverlay()
        handler.postDelayed(ticker, 1000)
    }

    private fun drainLoop(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var track = -1
        try {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer!!.addTrack(enc.outputFormat)
                        muxer!!.start()
                        muxerStarted = true
                    }
                    idx >= 0 -> {
                        val buf = enc.getOutputBuffer(idx)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (buf != null && info.size > 0 && muxerStarted) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            muxer!!.writeSampleData(track, buf, info)
                            frames++
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        } catch (_: Exception) {
            // fall through to finalize whatever was written
        }
        finalizeFile()
    }

    private fun requestStop() {
        if (!stopping.compareAndSet(false, true)) return
        handler.removeCallbacks(ticker)
        removeOverlay()
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { encoder?.signalEndOfInputStream() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun finalizeFile() {
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        encoder = null
        try { if (muxerStarted) muxer?.stop() } catch (_: Exception) { muxerStarted = false }
        try { muxer?.release() } catch (_: Exception) {}
        muxer = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null

        val uri = outUri
        if (uri != null) {
            if (frames > 0 && muxerStarted) {
                val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, v, null, null)
                lastUri = uri
            } else {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
            }
        }
        handler.post {
            running = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    /** Startup failed: release everything and drop the empty file. */
    private fun abort() {
        handler.removeCallbacks(ticker)
        removeOverlay()
        try { display?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        outUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
        display = null; projection = null; encoder = null; muxer = null; pfd = null; outUri = null
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------- floating FPS overlay ----------------

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "FPS –"
            textSize = 16f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#4ade80"))
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(48)
        }
        // drag to move
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    try { wm.updateViewLayout(tv, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(tv, lp)
            overlay = tv
            overlayParams = lp
        } catch (_: Exception) {
            overlay = null
        }
    }

    private fun removeOverlay() {
        val tv = overlay ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(tv)
        } catch (_: Exception) {}
        overlay = null
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (running) requestStop()
        super.onDestroy()
    }
}
