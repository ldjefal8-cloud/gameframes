package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 100
    private val reqPick = 101

    private lateinit var status: TextView
    private lateinit var qual: Spinner
    private lateinit var fps: Spinner
    private lateinit var bitrate: Spinner
    private lateinit var orient: Spinner
    private lateinit var overlayCb: CheckBox
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnLast: Button

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(20))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(label("🎮 Game Frames", 24f))
        root.addView(label("سجّل شاشتك أثناء اللعب مع عدّاد FPS عائم، ثم راجع الفريمات واحفظها كصور.", 13f, MUTE))

        status = label("جاهز", 18f, GREEN)
        status.setPadding(0, dp(16), 0, dp(8))
        root.addView(status)

        qual = spinner(listOf("720p", "1080p", "أصلية"), 1)
        fps = spinner(listOf("30", "60"), 1)
        bitrate = spinner(listOf("4 Mbps", "8 Mbps", "16 Mbps"), 1)
        orient = spinner(listOf("أفقي (للألعاب)", "عمودي"), 0)

        root.addView(field("الجودة", qual))
        root.addView(field("الفريمات المطلوبة", fps))
        root.addView(field("Bitrate", bitrate))
        root.addView(field("اتجاه التسجيل", orient))

        overlayCb = CheckBox(this).apply {
            text = "إظهار عدّاد FPS فوق اللعبة"
            isChecked = true
            setTextColor(Color.WHITE)
        }
        root.addView(overlayCb)

        btnStart = button("● بدء التسجيل", primary = true) { start() }
        btnStop = button("■ إيقاف التسجيل") { stop() }
        root.addView(row(btnStart, btnStop))

        btnLast = button("🎞 مراجعة آخر تسجيل") {
            RecorderService.lastUri?.let { openReview(it) }
        }
        val btnPick = button("📂 فتح فيديو للمراجعة") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(i, reqPick)
        }
        root.addView(row(btnLast, btnPick))

        root.addView(
            label(
                "ملاحظات:\n" +
                    "• عدّاد FPS يُحسب من الفريمات التي تصل للتسجيل، وهو تقدير قريب لـ FPS اللعبة وليس قراءة من داخلها.\n" +
                    "• العدّاد العائم يظهر داخل الفيديو المسجّل أيضًا.\n" +
                    "• الفيديوهات تُحفظ في Movies/GameFrames، واللقطات في Pictures/GameFrames.\n" +
                    "• التسجيل بدون صوت حاليًا.",
                12f, MUTE
            ).apply { setPadding(0, dp(16), 0, 0) }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun field(title: String, s: Spinner): LinearLayout =
        row(label(title, 14f), s).apply { gravity = android.view.Gravity.CENTER_VERTICAL }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val running = RecorderService.running
        btnStart.isEnabled = !running
        btnStop.isEnabled = running
        btnLast.isEnabled = RecorderService.lastUri != null
        if (running) {
            val s = (SystemClock.elapsedRealtime() - RecorderService.startMs) / 1000
            status.text = "● جارٍ التسجيل  %02d:%02d".format(s / 60, s % 60)
            status.setTextColor(Color.parseColor("#ef4444"))
        } else {
            status.text = "جاهز"
            status.setTextColor(GREEN)
        }
    }

    private fun start() {
        if (overlayCb.isChecked && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع واضغط بدء", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    private fun stop() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                    .putExtra("height", listOf(720, 1080, 0)[qual.selectedItemPosition])
                    .putExtra("fps", listOf(30, 60)[fps.selectedItemPosition])
                    .putExtra("bitrate", listOf(4, 8, 16)[bitrate.selectedItemPosition] * 1_000_000)
                    .putExtra("landscape", orient.selectedItemPosition == 0)
                    .putExtra("overlay", overlayCb.isChecked)
                startForegroundService(svc)
                Toast.makeText(this, "بدأ التسجيل، ارجع للعبة", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        } else if (requestCode == reqPick && resultCode == RESULT_OK) {
            data?.data?.let { openReview(it) }
        }
    }

    private fun openReview(uri: Uri) {
        startActivity(
            Intent(this, ReviewActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
