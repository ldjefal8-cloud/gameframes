package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val reqCapture = 100
    private val reqPick = 101
    private val reqAudioPerm = 102

    private val heights = listOf(720, 1080, 1440, 2160, 0)   // short side in px, 0 = native
    private val fpsList = listOf(24, 30, 45, 60, 90, 120, 144)
    private val bitrates = listOf(0, 2, 4, 6, 8, 12, 16, 20, 30, 40, 60, 80, 100)  // Mbps, 0 = auto
    private val delays = listOf(0, 3, 5, 10)

    private lateinit var status: TextView
    private lateinit var qual: Spinner
    private lateinit var fps: Spinner
    private lateinit var comp: Spinner
    private lateinit var orient: Spinner
    private lateinit var audio: Spinner
    private lateinit var delay: Spinner
    private lateinit var overlayCb: CheckBox
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnLast: Button

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dm = realMetrics()
        val nShort = min(dm.widthPixels, dm.heightPixels)
        val nLong = max(dm.widthPixels, dm.heightPixels)
        val maxHz = maxRefreshRate()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(20))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(label("🎮 Game Frames", 24f))
        root.addView(label("سجّل شاشتك أثناء اللعب مع عدّاد FPS عائم، ثم راجع الفريمات واحفظها كصور.", 13f, MUTE))
        root.addView(
            label(
                "شاشتك: $nLong×$nShort · حتى ${maxHz}Hz\n" +
                    "⚠ = فوق معدل تحديث شاشتك (لن تحصل على فريمات إضافية).\n↑ = أعلى من دقة شاشتك (يُسجَّل بهذا الحجم فعلًا إن دعمه هاتفك).",
                12f, GREEN
            ).apply { setPadding(0, dp(10), 0, 0) }
        )

        status = label("جاهز", 18f, GREEN)
        status.setPadding(0, dp(14), 0, dp(8))
        root.addView(status)

        val qItems = listOf(720, 1080, 1440, 2160).map {
            val name = if (it == 2160) "2160p (4K · 3840)" else "${it}p"
            if (it > nShort) "$name ↑" else name
        } + "أصلية (${nShort}p)"
        val fItems = fpsList.map { if (it > maxHz) "$it ⚠" else "$it" }

        qual = spinner(qItems, 1)
        fps = spinner(fItems, 3)
        comp = spinner(bitrates.map { if (it == 0) "تلقائي" else "$it Mbps" }, 0)
        orient = spinner(listOf("تلقائي (حسب دوران الهاتف)", "أفقي (للألعاب)", "عمودي"), 0)
        audio = spinner(listOf("بدون صوت", "صوت النظام (اللعبة)", "الميكروفون", "النظام + الميكروفون"), 1)
        delay = spinner(listOf("بدون", "3 ثوان", "5 ثوان", "10 ثوان"), 1)

        root.addView(field("الدقة", qual))
        root.addView(field("الفريمات (FPS)", fps))
        root.addView(field("البتريت (Bitrate)", comp))
        root.addView(field("اتجاه التسجيل", orient))
        root.addView(field("مصدر الصوت", audio))
        root.addView(field("تأخير البدء", delay))

        overlayCb = CheckBox(this).apply {
            text = "إظهار عدّاد FPS فوق اللعبة"
            isChecked = true
            setTextColor(Color.WHITE)
        }
        root.addView(overlayCb)

        btnStart = button("● بدء التسجيل", primary = true) { start() }
        btnStop = button("■ إيقاف التسجيل") { stop() }
        root.addView(row(btnStart, btnStop))

        btnLast = button("🎞 مراجعة آخر تسجيل") {
            RecorderService.lastUri?.let { openReview(it) }
        }
        val btnPick = button("📂 فتح فيديو للمراجعة") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(i, reqPick)
        }
        root.addView(row(btnLast, btnPick))

        root.addView(
            label(
                "ملاحظات:\n" +
                    "• الدقة تُسجَّل بالحجم الذي تختاره فعلًا (إن دعمه مشفّر هاتفك، وإلا تظهر لك رسالة بما سُجّل). FPS الفعلي لا يتجاوز معدل تحديث شاشتك ولا FPS اللعبة نفسها (فعّل 90/120Hz من إعدادات الهاتف وفي اللعبة).\n" +
                    "• البتريت اليدوي يُطبَّق بنمط ثابت (CBR) إن دعمه الهاتف. «تلقائي» يحسبه من الدقة والفريمات.\n" +
                    "• الاتجاه التلقائي: إذا دارت الشاشة أثناء التسجيل يبدأ ملف جديد (جزء) بالاتجاه الجديد. استعمل «تأخير البدء» لتنتقل للعبة قبل أن يبدأ التسجيل.\n" +
                    "• صوت النظام يلتقط صوت اللعبة مباشرة بدون ميكروفون. بعض التطبيقات تمنع التقاط صوتها فيظهر صامتًا. الميكروفون يلتقط صوتك وما حولك.\n" +
                    "• عدّاد FPS تقدير من الفريمات الواصلة للتسجيل، وهو يظهر داخل الفيديو أيضًا.\n" +
                    "• الفيديوهات في Movies/GameFrames، واللقطات في Pictures/GameFrames.",
                12f, MUTE
            ).apply { setPadding(0, dp(16), 0, 0) }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun field(title: String, s: Spinner): LinearLayout =
        row(label(title, 14f), s).apply { gravity = Gravity.CENTER_VERTICAL }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val running = RecorderService.running
        btnStart.isEnabled = !running
        btnStop.isEnabled = running
        btnLast.isEnabled = RecorderService.lastUri != null
        if (running) {
            val now = SystemClock.elapsedRealtime()
            if (now < RecorderService.startMs) {
                val left = (RecorderService.startMs - now + 999) / 1000
                status.text = "يبدأ التسجيل بعد $left ث، انتقل للعبة الآن"
                status.setTextColor(Color.parseColor("#fbbf24"))
            } else {
                val s = (now - RecorderService.startMs) / 1000
                status.text = "● جارٍ التسجيل  %02d:%02d".format(s / 60, s % 60)
                status.setTextColor(Color.parseColor("#ef4444"))
            }
        } else {
            status.text = "جاهز"
            status.setTextColor(GREEN)
        }
    }

    private fun start() {
        if (audio.selectedItemPosition != 0 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudioPerm)
            return
        }
        if (overlayCb.isChecked && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع واضغط بدء", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqAudioPerm) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                start()
            } else {
                Toast.makeText(this, "الصوت يحتاج إذن التسجيل الصوتي. اختر «بدون صوت» أو اسمح بالإذن.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stop() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val d = delays[delay.selectedItemPosition]
                val svc = Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                    .putExtra("height", heights[qual.selectedItemPosition])
                    .putExtra("fps", fpsList[fps.selectedItemPosition])
                    .putExtra("bitrate", bitrates[comp.selectedItemPosition] * 1_000_000)
                    .putExtra("orient", orient.selectedItemPosition)
                    .putExtra("audio", audio.selectedItemPosition)
                    .putExtra("delay", d)
                    .putExtra("overlay", overlayCb.isChecked)
                startForegroundService(svc)
                val msg = if (d > 0) "سيبدأ التسجيل بعد $d ثوان، انتقل للعبة" else "بدأ التسجيل، ارجع للعبة"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        } else if (requestCode == reqPick && resultCode == RESULT_OK) {
            data?.data?.let { openReview(it) }
        }
    }

    private fun openReview(uri: Uri) {
        startActivity(
            Intent(this, ReviewActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
