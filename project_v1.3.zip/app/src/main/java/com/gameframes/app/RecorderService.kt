package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min

/**
 * Screen recorder: one MediaProjection + one VirtualDisplay feeding a MediaCodec input surface.
 *
 * - Resolution is recorded at exactly the requested size when the encoder supports it (else steps down).
 * - Frame rate is whatever the display really delivers.
 * - Auto orientation: when the screen rotates, the current file is closed and a new part starts.
 * - Audio: system/game audio (AudioPlaybackCapture), microphone, or both mixed, encoded as AAC
 *   and muxed into the same MP4 as the video.
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "gf.start"
        const val ACTION_STOP = "gf.stop"
        private const val CHANNEL = "rec"
        private const val AVC = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val HEVC = MediaFormat.MIMETYPE_VIDEO_HEVC
        private const val AAC = MediaFormat.MIMETYPE_AUDIO_AAC
        private const val RATE = 44100

        @Volatile var running = false
        @Volatile var lastUri: Uri? = null
        @Volatile var startMs = 0L
    }

    private class EncCfg(
        val enc: MediaCodec, val mime: String,
        val w: Int, val h: Int, val fps: Int, val bitrate: Int
    )

    private val handler = Handler(Looper.getMainLooper())
    private val stopping = AtomicBoolean(false)
    private val pending = AtomicInteger(0)      // segments not yet finalized
    private val totalFrames = AtomicInteger(0)
    private var lastFrames = 0

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    @Volatile private var current: Segment? = null
    private var capturer: AudioCapturer? = null
    private var partNo = 0
    private var stampStr = ""
    private var startPending: Runnable? = null
    private var dpi = 320

    private var heightReq = 1080
    private var fpsReq = 60
    private var bpp = 0.11f
    private var bitrateReq = 0               // bits/s, 0 = automatic
    private var orientMode = 0              // 0 auto, 1 landscape, 2 portrait
    private var audioMode = 0                // 0 none, 1 system, 2 mic, 3 both
    private var showOverlay = true
    private var landscape = true

    private var overlay: TextView? = null

    private val ticker = object : Runnable {
        override fun run() {
            val f = totalFrames.get()
            val fps = f - lastFrames
            lastFrames = f
            val s = max(0L, (SystemClock.elapsedRealtime() - startMs) / 1000)
            val c = current?.cfg
            val size = if (c != null) "${c.w}x${c.h}" else ""
            overlay?.apply {
                text = "FPS %d\n%s\n● %02d:%02d".format(fps, size, s / 60, s % 60)
                setTextColor(
                    when {
                        fps >= 50 -> Color.parseColor("#4ade80")
                        fps >= 25 -> Color.parseColor("#fbbf24")
                        else -> Color.parseColor("#f87171")
                    }
                )
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val rotCheck = Runnable { checkRotation() }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            handler.removeCallbacks(rotCheck)
            handler.postDelayed(rotCheck, 600)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val cmd = intent ?: return START_NOT_STICKY
        when (cmd.action) {
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                stopping.set(false)
                running = true
                val wantsMic = cmd.getIntExtra("audio", 0).let { it == 2 || it == 3 }
                try {
                    startForegroundNow(wantsMic)
                    initRecording(cmd)
                } catch (e: Exception) {
                    toast("تعذّر بدء التسجيل: ${e.message}")
                    requestStop()
                }
            }
            ACTION_STOP -> {
                if (running) requestStop() else stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun startForegroundNow(withMic: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Game Frames")
            .setContentText("تسجيل الشاشة شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPi)
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (withMic && Build.VERSION.SDK_INT >= 30) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        startForeground(1, n, type)
    }

    @Suppress("DEPRECATION")
    private fun initRecording(intent: Intent) {
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
            ?: throw IllegalStateException("no permission data")
        heightReq = intent.getIntExtra("height", 1080)
        fpsReq = intent.getIntExtra("fps", 60)
        bitrateReq = intent.getIntExtra("bitrate", 0)
        orientMode = intent.getIntExtra("orient", 0)
        audioMode = intent.getIntExtra("audio", 0)
        showOverlay = intent.getBooleanExtra("overlay", true)
        val delaySec = intent.getIntExtra("delay", 3)

        dpi = realMetrics().densityDpi
        stampStr = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        totalFrames.set(0)
        lastFrames = 0
        partNo = 0

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { requestStop() }
            }
        }, handler)

        // startMs in the future = countdown shown in the app
        startMs = SystemClock.elapsedRealtime() + delaySec * 1000L
        val r = Runnable { beginRecording() }
        startPending = r
        handler.postDelayed(r, delaySec * 1000L)
    }

    // ---------------- orientation / size ----------------

    private fun isLandscapeNow(): Boolean {
        val m = realMetrics()
        return m.widthPixels > m.heightPixels
    }

    private fun decideLandscape(): Boolean = when (orientMode) {
        1 -> true
        2 -> false
        else -> isLandscapeNow()
    }

    /** Even-numbered size for the requested short side (0 = native). The virtual display is
     *  created at exactly this size, so the encoder really receives this resolution. */
    private fun sizeFor(shortReq: Int, land: Boolean): Pair<Int, Int> {
        val m = realMetrics()
        val nShort = min(m.widthPixels, m.heightPixels)
        val nLong = max(m.widthPixels, m.heightPixels)
        val sh = if (shortReq == 0) nShort else shortReq
        val lg = ((sh.toLong() * nLong) / nShort).toInt()
        val s = sh and 1.inv()
        val l = lg and 1.inv()
        return if (land) Pair(l, s) else Pair(s, l)
    }

    private fun hasEncoder(mime: String): Boolean =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(mime, true) }
        }

    /**
     * Picks the best encoder configuration the phone really supports, trying the requested
     * resolution first and falling back step by step (never inventing a higher one).
     */
    private fun buildEncoder(
        shortReq: Int, land: Boolean, fpsWanted: Int, bitsPerPx: Float, manualBps: Int
    ): EncCfg {
        val m = realMetrics()
        val limit = if (shortReq == 0) min(m.widthPixels, m.heightPixels) else shortReq
        val chain = (listOf(shortReq) + listOf(2160, 1440, 1080, 720, 480).filter { it < limit })
            .distinct()
        val heavy = shortReq == 0 || shortReq >= 1440 || fpsWanted > 60
        val mimes = (if (heavy) listOf(HEVC, AVC) else listOf(AVC, HEVC)).filter { hasEncoder(it) }

        for (sr in chain) {
            val (w, h) = sizeFor(sr, land)
            for (mime in mimes) {
                var enc: MediaCodec? = null
                try {
                    enc = MediaCodec.createEncoderByType(mime)
                    val caps = enc.codecInfo.getCapabilitiesForType(mime)
                    val vc = caps.videoCapabilities
                    if (!vc.isSizeSupported(w, h)) {
                        enc.release()
                        continue
                    }
                    val maxFps = vc.getSupportedFrameRatesFor(w, h).upper.toInt()
                    val fps = min(fpsWanted, max(24, maxFps))
                    val factor = if (mime == HEVC) 0.7f else 1f
                    val wanted = if (manualBps > 0) manualBps else
                        (w.toFloat() * h * fps * bitsPerPx * factor).toLong()
                            .coerceIn(4_000_000L, 100_000_000L).toInt()
                    val br = vc.bitrateRange.clamp(wanted)
                    val ec = caps.encoderCapabilities
                    val mode = when {
                        manualBps > 0 && ec.isBitrateModeSupported(
                            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                        ) -> MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                        ec.isBitrateModeSupported(
                            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                        ) -> MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                        else -> -1
                    }

                    val format = MediaFormat.createVideoFormat(mime, w, h).apply {
                        setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                        setInteger(MediaFormat.KEY_BIT_RATE, br)
                        setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                        setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
                        setInteger(MediaFormat.KEY_PRIORITY, 0)   // real-time
                        setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
                        if (mode >= 0) setInteger(MediaFormat.KEY_BITRATE_MODE, mode)
                    }
                    enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    return EncCfg(enc, mime, w, h, fps, br)
                } catch (e: Exception) {
                    try { enc?.release() } catch (_: Exception) {}
                }
            }
        }
        throw IllegalStateException("لا يوجد مشفّر فيديو مناسب")
    }

    private fun newSegment(land: Boolean): Segment {
        val cfg = buildEncoder(heightReq, land, fpsReq, bpp, bitrateReq)
        partNo++
        val seg = Segment(cfg, capturer?.ok == true)
        pending.incrementAndGet()
        return seg
    }

    // ---------------- start / rotate / stop ----------------

    private fun beginRecording() {
        startPending = null
        if (stopping.get()) return
        try {
            val proj = projection ?: throw IllegalStateException("no projection")

            if (audioMode != 0) {
                val cap = AudioCapturer(audioMode == 1 || audioMode == 3, audioMode == 2 || audioMode == 3, proj)
                if (cap.ok) capturer = cap
                else toast("تعذّر تشغيل الصوت، سيُسجَّل الفيديو بدون صوت")
            }

            landscape = decideLandscape()
            val seg = newSegment(landscape)
            display = proj.createVirtualDisplay(
                "GameFrames", seg.cfg.w, seg.cfg.h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                seg.surface, null, null
            )
            current = seg
            seg.start()
            capturer?.start()

            startMs = SystemClock.elapsedRealtime()
            lastFrames = totalFrames.get()
            if (showOverlay && android.provider.Settings.canDrawOverlays(this)) addOverlay()
            handler.postDelayed(ticker, 1000)
            if (orientMode == 0) {
                getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
            }

            val c = seg.cfg
            val codec = if (c.mime == HEVC) "H.265" else "H.264"
            val sb = StringBuilder("تسجيل ${c.w}×${c.h} · $codec · ${c.bitrate / 1_000_000} Mbps")
            if (capturer != null) sb.append(" · صوت")
            if (heightReq != 0 && min(c.w, c.h) < heightReq) {
                sb.append("\nالدقة المطلوبة (${heightReq}p) غير مدعومة في هاتفك، سُجّل بأعلى دقة حقيقية متاحة.")
            }
            if (bitrateReq > 0 && c.bitrate != bitrateReq) {
                sb.append("\nالبتريت المطلوب ${bitrateReq / 1_000_000} Mbps خارج مدى المشفّر، استُعمل ${c.bitrate / 1_000_000} Mbps.")
            }
            if (c.fps < fpsReq) {
                sb.append("\nمشفّر هاتفك يدعم حتى ${c.fps} fps بهذه الدقة.")
            }
            val hz = maxRefreshRate()
            if (fpsReq > hz) sb.append("\nشاشتك تدعم حتى ${hz}Hz فقط، فلن يتجاوز FPS الحقيقي ذلك.")
            toast(sb.toString())
        } catch (e: Exception) {
            toast("تعذّر بدء التسجيل: ${e.message}")
            requestStop()
        }
    }

    private fun checkRotation() {
        if (orientMode != 0 || stopping.get()) return
        val old = current ?: return
        val disp = display ?: return
        val nowLand = isLandscapeNow()
        if (nowLand == landscape) return
        try {
            val seg = newSegment(nowLand)
            disp.resize(seg.cfg.w, seg.cfg.h, dpi)
            disp.surface = seg.surface
            current = seg
            landscape = nowLand
            seg.start()
            old.end()
            toast("دارت الشاشة: بدأ جزء جديد ${seg.cfg.w}×${seg.cfg.h}")
        } catch (e: Exception) {
            // keep recording into the old segment
        }
    }

    private fun requestStop() {
        if (!stopping.compareAndSet(false, true)) return
        startPending?.let { handler.removeCallbacks(it) }
        startPending = null
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(rotCheck)
        try {
            getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener)
        } catch (_: Exception) {}
        removeOverlay()
        try { display?.release() } catch (_: Exception) {}
        display = null
        capturer?.stop()          // stop feeding audio before the segment is closed
        capturer = null
        current?.end()
        current = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        maybeFinish()
    }

    private fun maybeFinish() {
        if (stopping.get() && pending.get() == 0 && running) {
            running = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------------- audio capture (system and/or microphone) ----------------

    private inner class AudioCapturer(useSys: Boolean, useMic: Boolean, proj: MediaProjection) {
        private val bytes = 4096                       // 1024 stereo 16-bit frames per chunk
        private var sys: AudioRecord? = null
        private var mic: AudioRecord? = null
        @Volatile private var alive = true
        private var thread: Thread? = null
        val ok: Boolean

        init {
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufSize = max(minBuf, bytes * 4)

            if (useSys) {
                try {
                    val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()
                    sys = AudioRecord.Builder()
                        .setAudioFormat(fmt)
                        .setBufferSizeInBytes(bufSize)
                        .setAudioPlaybackCaptureConfig(cfg)
                        .build()
                } catch (_: Exception) {
                    sys = null
                }
            }
            if (useMic) {
                try {
                    mic = AudioRecord.Builder()
                        .setAudioSource(MediaRecorder.AudioSource.MIC)
                        .setAudioFormat(fmt)
                        .setBufferSizeInBytes(bufSize)
                        .build()
                } catch (_: Exception) {
                    mic = null
                }
            }
            if (sys != null && sys!!.state != AudioRecord.STATE_INITIALIZED) {
                try { sys!!.release() } catch (_: Exception) {}
                sys = null
            }
            if (mic != null && mic!!.state != AudioRecord.STATE_INITIALIZED) {
                try { mic!!.release() } catch (_: Exception) {}
                mic = null
            }
            ok = sys != null || mic != null
        }

        fun start() {
            thread = Thread({ loop() }, "gf-audio").also { it.start() }
        }

        private fun loop() {
            val s = sys
            val m = mic
            val a = ByteArray(bytes)
            val b = ByteArray(bytes)
            var framesDone = 0L
            var baseUs = -1L
            try {
                s?.startRecording()
                m?.startRecording()
                while (alive) {
                    val ns = if (s != null) s.read(a, 0, bytes) else 0
                    val nm = if (m != null) m.read(b, 0, bytes) else 0
                    if ((s != null && ns < 0) || (m != null && nm < 0)) break

                    val out: ByteArray
                    val n: Int
                    if (s != null && m != null) {
                        n = min(ns, nm)
                        var i = 0
                        while (i + 1 < n) {
                            val x = (a[i].toInt() and 0xff) or (a[i + 1].toInt() shl 8)
                            val y = (b[i].toInt() and 0xff) or (b[i + 1].toInt() shl 8)
                            val mixed = (x + y).coerceIn(-32768, 32767)
                            a[i] = (mixed and 0xff).toByte()
                            a[i + 1] = ((mixed shr 8) and 0xff).toByte()
                            i += 2
                        }
                        out = a
                    } else if (s != null) {
                        n = ns; out = a
                    } else {
                        n = nm; out = b
                    }
                    if (n <= 0) continue

                    val chunkFrames = n / 4
                    val chunkUs = chunkFrames * 1_000_000L / RATE
                    if (baseUs < 0) baseUs = System.nanoTime() / 1000 - chunkUs
                    val pts = baseUs + framesDone * 1_000_000L / RATE
                    framesDone += chunkFrames
                    current?.feedAudio(out, n, pts)
                }
            } catch (_: Exception) {
                // stop capturing; video keeps recording
            }
        }

        fun stop() {
            alive = false
            try { thread?.join(800) } catch (_: InterruptedException) {}
            try { sys?.stop() } catch (_: Exception) {}
            try { mic?.stop() } catch (_: Exception) {}
            try { sys?.release() } catch (_: Exception) {}
            try { mic?.release() } catch (_: Exception) {}
            sys = null
            mic = null
        }
    }

    // ---------------- one output file (video + optional audio) ----------------

    private inner class Segment(val cfg: EncCfg, private val withAudio: Boolean) {
        private val enc = cfg.enc
        val surface: Surface = enc.createInputSurface()
        private var aenc: MediaCodec? = null
        private var muxer: MediaMuxer? = null
        private var pfd: ParcelFileDescriptor? = null
        private var uri: Uri? = null

        private val muxLock = Any()
        private val audioLock = Any()
        @Volatile private var muxerStarted = false
        @Volatile private var audioDisabled = false
        @Volatile private var endRequested = false
        @Volatile private var audioEos = false
        private var videoTrack = -1
        private var audioTrack = -1
        private var added = 0
        private val needed = if (withAudio) 2 else 1
        private val drains = AtomicInteger(needed)
        private var frames = 0
        private var lastAudioPts = 0L

        init {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "game-$stampStr-p$partNo.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GameFrames")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("cannot create file")
                uri = u
                pfd = contentResolver.openFileDescriptor(u, "rw")
                    ?: throw IllegalStateException("cannot open file")
                muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                enc.start()

                if (withAudio) {
                    val af = MediaFormat.createAudioFormat(AAC, RATE, 2).apply {
                        setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                        setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                        setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    }
                    val ae = MediaCodec.createEncoderByType(AAC)
                    ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    ae.start()
                    aenc = ae
                }
            } catch (e: Exception) {
                try { enc.release() } catch (_: Exception) {}
                try { aenc?.release() } catch (_: Exception) {}
                try { muxer?.release() } catch (_: Exception) {}
                try { pfd?.close() } catch (_: Exception) {}
                uri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                throw e
            }
        }

        fun start() {
            Thread({ drainVideo() }, "gf-vdrain-$partNo").start()
            if (aenc != null) Thread({ drainAudio() }, "gf-adrain-$partNo").start()
        }

        fun end() {
            endRequested = true
            try { enc.signalEndOfInputStream() } catch (_: Exception) {}
            endAudio()
        }

        // ----- audio input (called from the capture thread) -----

        fun feedAudio(data: ByteArray, size: Int, ptsUs: Long) {
            val e = aenc ?: return
            synchronized(audioLock) {
                if (audioEos) return
                try {
                    var off = 0
                    while (off < size) {
                        val idx = e.dequeueInputBuffer(10_000)
                        if (idx < 0) return          // encoder busy: drop this chunk
                        val ib = e.getInputBuffer(idx) ?: return
                        ib.clear()
                        val n = min(ib.remaining(), size - off)
                        ib.put(data, off, n)
                        val chunkPts = ptsUs + (off / 4L) * 1_000_000L / RATE
                        lastAudioPts = chunkPts
                        e.queueInputBuffer(idx, 0, n, chunkPts, 0)
                        off += n
                    }
                } catch (_: Exception) {}
            }
        }

        private fun endAudio() {
            val e = aenc ?: return
            synchronized(audioLock) {
                if (audioEos) return
                audioEos = true
                try {
                    val idx = e.dequeueInputBuffer(100_000)
                    if (idx >= 0) e.queueInputBuffer(idx, 0, 0, lastAudioPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                } catch (_: Exception) {}
            }
        }

        // ----- muxer coordination -----

        /** Called with muxLock held after a track was added. */
        private fun trackReady() {
            added++
            if (added >= needed && !muxerStarted) {
                muxer!!.start()
                muxerStarted = true
            }
        }

        /** Waits for the muxer to start. Video may force a video-only start if audio never arrives. */
        private fun awaitStart(force: Boolean): Boolean {
            var waited = 0
            while (!muxerStarted && waited < 3000) {
                if (force && waited >= 1500) {
                    synchronized(muxLock) {
                        if (!muxerStarted && videoTrack >= 0) {
                            muxer!!.start()
                            muxerStarted = true
                            audioDisabled = true
                        }
                    }
                    break
                }
                try { Thread.sleep(5) } catch (_: InterruptedException) {}
                waited += 5
            }
            return muxerStarted
        }

        // ----- drain threads -----

        private fun drainVideo() {
            val info = MediaCodec.BufferInfo()
            var idle = 0
            try {
                while (true) {
                    val idx = enc.dequeueOutputBuffer(info, 10_000)
                    when {
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            synchronized(muxLock) {
                                videoTrack = muxer!!.addTrack(enc.outputFormat)
                                trackReady()
                            }
                        }
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (endRequested && ++idle > 400) break
                        }
                        idx >= 0 -> {
                            idle = 0
                            val buf = enc.getOutputBuffer(idx)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (buf != null && info.size > 0 && awaitStart(true)) {
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                synchronized(muxLock) { muxer!!.writeSampleData(videoTrack, buf, info) }
                                frames++
                                totalFrames.incrementAndGet()
                            }
                            enc.releaseOutputBuffer(idx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                        }
                    }
                }
            } catch (_: Exception) {
                // finalize whatever was written
            }
            drainDone()
        }

        private fun drainAudio() {
            val e = aenc ?: return drainDone()
            val info = MediaCodec.BufferInfo()
            var idle = 0
            try {
                while (true) {
                    val idx = e.dequeueOutputBuffer(info, 10_000)
                    when {
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            synchronized(muxLock) {
                                if (!muxerStarted && !audioDisabled) {
                                    audioTrack = muxer!!.addTrack(e.outputFormat)
                                    trackReady()
                                } else {
                                    audioDisabled = true
                                }
                            }
                        }
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (audioEos && ++idle > 400) break
                        }
                        idx >= 0 -> {
                            idle = 0
                            val buf = e.getOutputBuffer(idx)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (buf != null && info.size > 0 && !audioDisabled && audioTrack >= 0 && awaitStart(false)) {
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                synchronized(muxLock) { muxer!!.writeSampleData(audioTrack, buf, info) }
                            }
                            e.releaseOutputBuffer(idx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                        }
                    }
                }
            } catch (_: Exception) {
                // finalize whatever was written
            }
            drainDone()
        }

        private fun drainDone() {
            if (drains.decrementAndGet() == 0) finish()
        }

        private fun finish() {
            try { enc.stop() } catch (_: Exception) {}
            try { enc.release() } catch (_: Exception) {}
            aenc?.let {
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            synchronized(muxLock) {
                try { if (muxerStarted) muxer?.stop() } catch (_: Exception) { muxerStarted = false }
                try { muxer?.release() } catch (_: Exception) {}
            }
            try { pfd?.close() } catch (_: Exception) {}
            val u = uri
            if (u != null) {
                if (frames > 0 && muxerStarted) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(u, v, null, null)
                    lastUri = u
                } else {
                    try { contentResolver.delete(u, null, null) } catch (_: Exception) {}
                }
            }
            pending.decrementAndGet()
            handler.post { maybeFinish() }
        }
    }

    // ---------------- floating FPS overlay ----------------

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "FPS –"
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#4ade80"))
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(48)
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    try { wm.updateViewLayout(tv, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(tv, lp)
            overlay = tv
        } catch (_: Exception) {
            overlay = null
        }
    }

    private fun removeOverlay() {
        val tv = overlay ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(tv)
        } catch (_: Exception) {}
        overlay = null
    }

    override fun onDestroy() {
        if (running) requestStop()
        super.onDestroy()
    }
}
