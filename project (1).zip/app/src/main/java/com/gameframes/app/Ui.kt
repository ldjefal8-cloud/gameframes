package com.gameframes.app

import android.content.Context
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import kotlin.math.roundToInt

val BG = Color.parseColor("#0e1116")
val MUTE = Color.parseColor("#8b95a5")
val GREEN = Color.parseColor("#4ade80")

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

/** Real physical screen size (includes system bars), unlike resources.displayMetrics. */
@Suppress("DEPRECATION")
fun Context.realMetrics(): DisplayMetrics {
    val dm = DisplayMetrics()
    getSystemService(DisplayManager::class.java)
        .getDisplay(Display.DEFAULT_DISPLAY)
        .getRealMetrics(dm)
    return dm
}

/** Highest refresh rate (Hz) any display mode of this phone supports. */
fun Context.maxRefreshRate(): Int {
    val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
    val best = d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
    return best.roundToInt()
}

fun Context.label(text: String, size: Float = 15f, color: Int = Color.WHITE): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

fun Context.button(text: String, primary: Boolean = false, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(if (primary) Color.parseColor("#04210f") else Color.WHITE)
        setBackgroundColor(if (primary) GREEN else Color.parseColor("#232a35"))
        setOnClickListener { onClick() }
    }

fun Context.spinner(items: List<String>, selected: Int = 0): Spinner =
    Spinner(this).apply {
        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected)
    }

/** Horizontal row; every child gets equal width. */
fun Context.row(vararg views: View): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            addView(it, lp)
        }
    }
